# Java-Quiz
This is a java program which will conduct a quiz from the given files of questions and answers given in the format of the example files given.
In this program we will be having 4 levels each contains 15 questions and there is a cutoff marks of 8 for each level.
